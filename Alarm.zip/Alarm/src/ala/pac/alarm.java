package ala.pac;

public class alarm 
{
 String mname,ip,gn,status,category;
 int port;
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getIp() {
	return ip;
}
public void setIp(String ip) {
	this.ip = ip;
}
public String getGn() {
	return gn;
}
public void setGn(String gn) {
	this.gn = gn;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public int getPort() {
	return port;
}
public void setPort(int port) {
	this.port = port;
}
 
}
