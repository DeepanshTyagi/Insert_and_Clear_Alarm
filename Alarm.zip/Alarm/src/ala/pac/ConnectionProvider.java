package ala.pac;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionProvider
{
	static Connection  con=null;
	static String  username="postgres";
	static String pwd="123456";
	static String connURL="jdbc:postgresql://127.0.0.1:5432/alarm";
	 public static Connection getCon()
	 {
		 try
		 {
			 Class.forName("org.postgresql.Driver");
			 con=DriverManager.getConnection(connURL,username,pwd);
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex);
		 }
		 return con;
	 }
}
