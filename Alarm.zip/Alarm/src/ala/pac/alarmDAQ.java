package ala.pac;
import java.sql.*;
public class alarmDAQ 
{
 static Connection conn;
 static PreparedStatement pst;
 

  public static int insertalarm (alarm a)
  {
	  int  status=0;
	  try
	  {
		  java.util.Date today = new java.util.Date();//date object
		  conn=ConnectionProvider.getCon();
		  pst=conn.prepareStatement("insert into alarminformation8 values(?,?,?,?,?,?,?)");
		  pst.setString(1,a.getMname());
		  pst.setString(2,a.getIp());
		  pst.setInt(3,a.getPort());
		  pst.setString(4,a.getStatus());
		  pst.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
		  pst.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
		  pst.setString(7,a.getCategory());
		  status=pst.executeUpdate();
		  conn.close();
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	  return status;
  }
}

